# Noch offene praktische Voraussetzungen

Die belegten Consent- und Publisher-Fehler sind von der ungeklärten Geräteursache des nativen Google-Statuscodes 10 zu trennen.

Zusätzlich zum passenden Package-/Zertifikateintrag ist der tatsächliche OAuth-Projekt-/Audience-/Consent-Zustand zu prüfen. Bei Publishing-Status Testing können Autorisierungen von Testnutzern nach sieben Tagen auslaufen. Das ist ein separater Grund, keine dauerhafte kommerzielle Freigabe aus einem erfolgreichen ersten Login abzuleiten. Der aktuelle Status des konkreten Projekts wurde nicht eingesehen; Testing wird hier nicht als bewiesene Ursache behauptet.

Primärquelle: https://support.google.com/cloud/answer/15549945?hl=en

Für eine unterstützte gezielte Modernisierung beschreibt Google AuthorizationClient.authorize(): Bei bereits gewährten Scopes kann dieselbe API ohne Nutzerinteraktion einen Access-Token liefern; andernfalls erhält die App eine zu behandelnde PendingIntent. Diese API ersetzt nicht die korrekte externe OAuth-/Signaturkonfiguration. Credential Manager allein erteilt keine Drive-Freigabe. Die vorliegende Reparatur stellt den verlorenen bestehenden recoverable Consent wieder her und wird nicht als vollständige Migration oder nachgewiesener Code10-Gerätefix ausgegeben.

Primärquelle: https://developers.google.com/android/reference/com/google/android/gms/auth/api/identity/AuthorizationClient

Keine reale Google-Autorisierung, keine POCO-Installation und kein Geräteupdate durchgeführt. Keine bestehende Installation deinstallieren. Aktueller praktischer Veröffentlichungsstatus: NO-GO.

Belegter Diagnosegrund für eine direkte Prüfung auf dem Gerät: `android-ci.yml` und `publish-verified-apk.yml` verwenden beide `debug-${github.sha}` und denselben APK-Dateinamen. Frühere zufällige Signierung konnte deshalb an einem gleich benannten Release unterschiedliche Zertifikate erzeugen. Ob die installierte POCO-App vom später untersuchten Download abwich, bleibt ohne direkt ausgelesene Gerätesignatur ungeklärt. Die Reparatur erzwingt dieselbe zugelassene Signatur für beide Publisher.

Die temporär signierte CI-APK nur auf einem separaten leeren Testgerät oder einem neuen Emulator verwenden. Keine Installation, Deinstallation oder Profiländerung auf dem POCO als Umgehung der Signaturgrenze durchführen. Ein datenbewahrendes Update der vorhandenen App verlangt den passenden Originalschlüssel bzw. einen gesondert geprüften Migrationsweg.
